#!/bin/bash

# Execute job from current working directory
#$ -cwd

# Gives the name for output of execution
#$ -o programoutput.$JOB_ID

# Ask the scheduler for allocating resources
#$ -pe smp-verbose 1

# Prints date
date

# Compiling the Program
gcc -fopenmp -std=gnu99 race.c -o race -lm

# Prints starting new job
echo "Starting new job"

# Set number of threads
export OMP_NUM_THREADS=4

# Executes the compiled program
./race

# Prints finished job
echo "Finished job"

# Prints date
date
