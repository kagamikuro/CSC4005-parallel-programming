#!/bin/bash

# Execute job from current working directory
#$ -cwd

# Gives the name for output of execution
#$ -o programoutput.$JOB_ID

# Ask the scheduler for allocating N cores
#$ -pe smp-verbose 1

# Prints date
date

# Compiling the Program
gcc -fopenmp -std=gnu99 interleave.c -o interleave -lm

# Prints starting new job
echo "Starting new job"

# Set number of OpenMP threads to run on N cores 
export OMP_NUM_THREADS=40

# Executes the compiled program
./interleave

# Prints finished job
echo "Finished job"

# Prints date
date
