#include <stdio.h>
#include <omp.h>

int main(int argc, char *argv[])
{
printf(" using %i processors\n -------------------\n", omp_get_num_procs());
for (int i=2; i<24; i=i+2) 
{
	printf("\n #threads %i \n", i);
	printf("-----------\n");
	#pragma omp parallel num_threads(i)
	{
		printf(" I am thread %i \n", omp_get_thread_num());

		#pragma omp single
		{
			printf(" Single construct executed by thread %i \n", omp_get_thread_num());
		}

		#pragma omp master
		{
			printf(" Master construct executed by thread %i \n", omp_get_thread_num());
		}
	} /* end parallel */
}

return 0;
}

