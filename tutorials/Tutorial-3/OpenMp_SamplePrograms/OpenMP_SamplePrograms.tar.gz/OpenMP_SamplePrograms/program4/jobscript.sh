#!/bin/bash

# Ask the scheduler for resources
#$ -pe smp-verbose 3

# Execute job from current working directory
#$ -cwd

# Gives the name for output of execution
#$ -o programoutput.$JOB_ID

# Prints date
date

# Compiling the Program
gcc -fopenmp -std=gnu99 bank.c -o bank -lm

# Prints starting new job
echo "Starting new job"

# Executes the compiled program
./bank

# Prints finished job
echo "Finished job"

# Prints date
date
